
function Name({children}) {
    return (
      <p className="text-sm font-bold text-gray-700">{children}</p>
    )
  }
  
  export default Name;