
function NormalText({children}) {
  return (
    <p className="text-gray-400 font-normal text-md">{children}</p>
  )
}

export default NormalText