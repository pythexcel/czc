

function Botname({children}) {
  return (
    <div className='text-xl font-medium text-blue-500 text-left break-words cursor-pointer'>{children}</div>
  )
}

export default Botname