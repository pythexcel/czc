

function Para({children}) {
  return (
    <div className="className='text-[17px] text-slate-500 font-normal text-left break-words cursor-pointer">{children}</div>
  )
}

export default Para