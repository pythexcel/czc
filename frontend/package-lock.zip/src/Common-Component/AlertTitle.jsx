
function AlertTitle() {
  return (
    <p className="text-red-500 text-sm float-left">AlertTitle</p>
  )
}

export default AlertTitle