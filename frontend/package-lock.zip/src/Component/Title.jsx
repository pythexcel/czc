

function Title({children}) {
  return (
    <p className="text-left text-xs text-slate-800 font-bold pb-2">{children}</p>
  )
}

export default Title