

function Section({children}) {
  return (
    <div className="mb-10">{children}</div>
  )
}

export default Section;