
function ModalPara({children}) {
  return (
    <div className='text-xs pb-2 text-gray-600 font-bold ml-1'>{children}</div>
  )
}

export default ModalPara