

function HeadingPoint({children}) {
  return (
    <p className="text-gray-500 font-bold text-lg mb-3">{children}</p>
  )
}

export default HeadingPoint